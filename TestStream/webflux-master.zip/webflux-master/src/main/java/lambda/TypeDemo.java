package lambda;

/**
 * @Author:tanghui
 * @Date:2018/8/31 15:42
 */
interface IMath1 {
    int add();
}


public class TypeDemo {

    public static void main(String[] args) {
        IMath1[] iMath1s={()->0};
    }
}
